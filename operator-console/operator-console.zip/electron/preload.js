const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("questforge", {
  getProjectRoot: () => ipcRenderer.invoke("qf:getProjectRoot"),
  setProjectRoot: (projectRoot) => ipcRenderer.invoke("qf:setProjectRoot", projectRoot),
  listSubmissions: () => ipcRenderer.invoke("qf:listSubmissions"),
  getSubmissionSnapshot: (slug) => ipcRenderer.invoke("qf:getSubmissionSnapshot", slug),
  readTextFile: (filePath) => ipcRenderer.invoke("qf:readTextFile", filePath),
  writeTextFile: (filePath, value) => ipcRenderer.invoke("qf:writeTextFile", filePath, value),
  copyText: (value) => ipcRenderer.invoke("qf:copyText", value),
  openPath: (filePath) => ipcRenderer.invoke("qf:openPath", filePath),
  runAction: (action) => ipcRenderer.invoke("qf:runAction", action),
  createStagedSubmission: (payload) => ipcRenderer.invoke("qf:createStagedSubmission", payload),

  getMatchmakingOverview: () => ipcRenderer.invoke("qf:getMatchmakingOverview"),
  listMatchmakingProfiles: () => ipcRenderer.invoke("qf:listMatchmakingProfiles"),
  getMatchmakingProfile: (playerId) => ipcRenderer.invoke("qf:getMatchmakingProfile", playerId),
  listPairEvaluations: () => ipcRenderer.invoke("qf:listPairEvaluations"),
  getPairEvaluation: (matchId) => ipcRenderer.invoke("qf:getPairEvaluation", matchId),
  rebuildMatchmakingPool: () => ipcRenderer.invoke("qf:rebuildMatchmakingPool"),
  compareProfileAgainstPool: (playerId) => ipcRenderer.invoke("qf:compareProfileAgainstPool", playerId),
  buildGroupEvaluation: (playerIds) => ipcRenderer.invoke("qf:buildGroupEvaluation", playerIds),
  loadMatchmakingDemoDataset: () => ipcRenderer.invoke("qf:loadMatchmakingDemoDataset"),
  clearMatchmakingDemoDataset: () => ipcRenderer.invoke("qf:clearMatchmakingDemoDataset")
});
